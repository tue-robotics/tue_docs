# TDPTemplate
Template for the Team Description Paper
